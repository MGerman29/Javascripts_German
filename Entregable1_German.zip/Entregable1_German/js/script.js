// Entrada de datos

function solicitarGastos() {
  const gastos = [];

  gastos.push(Number(prompt("¿Cuánto gastás por día en desayuno?")));
  gastos.push(Number(prompt("¿Cuánto gastás por día en transporte?")));
  gastos.push(Number(prompt("¿Cuánto gastás por día en almuerzo?")));
  gastos.push(Number(prompt("¿Cuánto gastás por día en delivery o comida afuera?")));

  return gastos;
} 

// Procesamiento de información

function calcularGastoTotal(gastos) {
  let total = 0;
  for (let i = 0; i < gastos.length; i++) {
    total += gastos[i];
  }
  return total;
}

// Salida de resultados

function mostrarResultado(gastoTotal, promedio) {
  console.log("Gasto total calculado: $" + gastoTotal);

  if (gastoTotal > promedio) {
    alert(`Estás gastando de mas.\nTu gasto estimado es de $${gastoTotal}, que supera el promedio diario de $${promedio}.`);
  } else if (gastoTotal < promedio) {
    alert(`Joya! Estás por debajo del gasto promedio.\nTu gasto diario es $${gastoTotal}. Segui metiendole asi`);
  } else {
    alert(`Estás justo en el promedio. Tu gasto diario es $${gastoTotal}.`);
  }
}

// Ejecución del programa

function gastosDiarios() {
    const gastos = solicitarGastos();
    const total = calcularGastoTotal(gastos);
    mostrarResultado(total, 15000); 

    const calcularDeNuevo = confirm("¿Querés calcular de nuevo?");
    if (calcularDeNuevo) {
        gastosDiarios();
    }else {
        alert("Gracias por usar el programa de gastos diarios. ¡Hasta luego!");
    }
}
gastosDiarios();